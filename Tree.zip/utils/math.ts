import * as THREE from 'three';

// Random point in sphere
export const getRandomSpherePoint = (radius: number): THREE.Vector3 => {
  const u = Math.random();
  const v = Math.random();
  const theta = 2 * Math.PI * u;
  const phi = Math.acos(2 * v - 1);
  const r = Math.cbrt(Math.random()) * radius;
  const sinPhi = Math.sin(phi);
  return new THREE.Vector3(
    r * sinPhi * Math.cos(theta),
    r * sinPhi * Math.sin(theta),
    r * Math.cos(phi)
  );
};

// Spiral distribution on a cone
export const getConePoint = (
  height: number,
  baseRadius: number,
  progress: number, // 0 to 1 (top to bottom usually, or index based)
  angleOffset: number = 0
): THREE.Vector3 => {
  // y goes from -height/2 to height/2
  const y = (progress - 0.5) * height; 
  
  // Radius decreases as we go up (y increases)
  // Inverse relationship: High Y = Low Radius
  const currentRadius = baseRadius * (1 - progress); 
  
  const angle = progress * Math.PI * 20 + angleOffset; // 10 spirals
  
  const x = currentRadius * Math.cos(angle);
  const z = currentRadius * Math.sin(angle);
  
  return new THREE.Vector3(x, y, z);
};

// Gaussian random for more natural distribution
export const randomNormalDistribution = (mean: number, stdDev: number): number => {
  const u = 1 - Math.random();
  const v = Math.random();
  const z = Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
  return z * stdDev + mean;
};
